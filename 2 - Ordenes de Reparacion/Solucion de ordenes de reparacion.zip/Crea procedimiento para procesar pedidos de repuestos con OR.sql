-- ******************************************************************************
-- AGREGA ITEMS DE REPUESTOS PEDIDOS A LA ORDEN DE REPARACION (FACTURA EN ESPERA)
-- ******************************************************************************
DROP PROCEDURE SESA_SP_PROCESA_PEDIDO_OR
GO 

CREATE PROCEDURE SESA_SP_PROCESA_PEDIDO_OR
@TipoDoc varchar(1), @OrdenReparacion Varchar(10)
WITH ENCRYPTION
AS

DECLARE @NroPedido varchar(10),
        @CodItem varchar(15),
        @NroLinea int,
        @CodUbic varchar(10),
        @Descrip1 varchar(50),
        @Cantidad decimal (28,2),
        @Costo decimal (28,2),
        @Precio decimal (28,2),
        @FechaE datetime,
        @FechaL datetime

BEGIN
   -- Si se trata de un pedido de repuestos para una orden de reparacion lo procesa
   IF EXISTS (SELECT NumeroD FROM dbo.SAFACT WHERE (TipoFac = 'G' and NumeroD = @OrdenReparacion))
   BEGIN
      -- Borra items de repuestos de la OR
      DELETE dbo.SAITEMFAC
         WHERE (TipoFac = 'G' AND NumeroD = @OrdenReparacion AND EsServ = 0)

      -- Procesa cada tipo de repuesto para todos los pedidos relacionados con la OR
      DECLARE MIREG CURSOR FOR
      SELECT DISTINCT X.CodItem
         FROM dbo.SAITEMFAC AS X
         INNER JOIN dbo.SESA_VW_ORDENES_REPARACION AS Y
         ON (X.TipoFac = Y.TipoFac and X.NumeroD = Y.NumeroD)
         WHERE (X.TipoFac = 'E' AND Y.Orden_de_reparacion = @OrdenReparacion)
      OPEN MIREG
      FETCH NEXT FROM MIREG INTO @CodItem
      WHILE (@@FETCH_STATUS = 0) 
      BEGIN

         -- Determina el proximo nro de linea
         SELECT @NroLinea = NroLinea + 1
            FROM  dbo.SAITEMFAC
            WHERE (TipoFac = 'G' and NumeroD = @OrdenReparacion)

         -- Determina la cantidad del repuesto entregado
         SELECT @Cantidad = SUM(X.Cantidad)
            FROM  dbo.SAITEMFAC AS X
            INNER JOIN dbo.SESA_VW_ORDENES_REPARACION AS Y
            ON (X.TipoFac = Y.TipoFac and X.NumeroD = Y.NumeroD)
            WHERE (X.TipoFac = 'E' and Y.Orden_de_reparacion = @OrdenReparacion and X.CodItem = @CodItem)
     
         -- Lee Costo y precio del item pedido.
         SELECT @CodUbic  = X.CodUbic,
                @Descrip1 = X.Descrip1,
                @Costo    = X.Costo,
                @Precio   = X.Precio,
                @FechaE   = X.FechaE,
                @FechaL   = X.FechaL
            FROM  dbo.SAITEMFAC AS X
            INNER JOIN dbo.SESA_VW_ORDENES_REPARACION AS Y
            ON (X.TipoFac = Y.TipoFac and X.NumeroD = Y.NumeroD)
            WHERE (X.TipoFac = 'E' and Y.Orden_de_reparacion = @OrdenReparacion and X.CodItem = @CodItem)

         -- Inserta item de repuesto en la OR.
         INSERT dbo.SAITEMFAC (TipoFac, NumeroD, CodItem, NroLinea, CodUbic, Descrip1, Costo, Cantidad, Precio, Signo, FechaE, FechaL)
            VALUES ('G', @OrdenReparacion, @CodItem, @NroLinea, @CodUbic, @Descrip1, @Costo, @Cantidad, @Precio, 1, @FechaE, @FechaL)

         FETCH NEXT FROM MIREG INTO @CodItem
      END
      CLOSE MIREG
      DEALLOCATE MIREG
   END
END