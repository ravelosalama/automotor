-- ********************************************************************************
-- TRIGGER PARA PROCESAR ORDENES DE REPARCION
-- ********************************************************************************
DROP TRIGGER SESA_TG_ESPERA_OR
GO
 
CREATE TRIGGER SESA_TG_ESPERA_OR ON SAFACT_01
WITH ENCRYPTION
AFTER INSERT, UPDATE
AS

DECLARE @TipoDoc varchar (1),
        @NumeroD varchar (15),
        @CodOper varchar (10),
        @OrdenReparacion Varchar(10)

BEGIN
   SELECT @TipoDoc = TipoFac,
          @NumeroD = NumeroD,
          @OrdenReparacion = Orden_de_reparacion
      FROM INSERTED

   SELECT @CodOper = X.CodOper
      FROM SAFACT AS X
      WHERE (X.TipoFac = @TipoDoc AND X.NumeroD = @NumeroD)

   -- Procesa nuevo pedido de repuestos para orden de reparacion
   IF @TipoDoc = 'E' AND @CodOper = '01-301'
      EXECUTE SESA_SP_PROCESA_PEDIDO_OR @TipoDoc, @OrdenReparacion
   ELSE
   -- Procesa nueva orden de reparacion
   IF @TipoDoc = 'G' AND @CodOper = '01-301'
      EXECUTE SESA_SP_PROCESA_ESPERA_OR @TipoDoc, @NumeroD
END






