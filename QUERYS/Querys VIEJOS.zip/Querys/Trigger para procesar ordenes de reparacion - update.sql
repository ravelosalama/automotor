DROP TRIGGER [SESA_TG_ORDEN_REPARACION-UPDATE]
GO
 
CREATE TRIGGER [SESA_TG_ORDEN_REPARACION-UPDATE] ON [dbo].[SAFACT_01] 
WITH ENCRYPTION
AFTER UPDATE
AS

DECLARE @CodOper varchar(10)
DECLARE @TipoDoc varchar(1)
DECLARE @NumeroD Varchar(10)
DECLARE @Deposito varchar(10)
DECLARE @CodInst varchar(10)
DECLARE @CodTaxs varchar(5)

SET @CodInst  = '12'
SET @Deposito = '020'
SET @CodTaxs  = 'IVA'

SELECT @TipoDoc = TipoFac FROM INSERTED
SELECT @NumeroD = NumeroD FROM INSERTED

SELECT @CodOper = Y.CodOper
FROM  dbo.SESA_VW_ORDENES_REPARACION AS X
LEFT OUTER JOIN dbo.SAFACT AS Y
ON (X.TipoFac = Y.TipoFac AND X.NumeroD = Y.NumeroD)
WHERE (X.TipoFac = @TipoDoc and X.NumeroD = @NumeroD)

IF @CodOper = '01-301' AND @TipoDoc = 'G'
BEGIN
   EXECUTE dbo.SESA_SP_ORDEN_REPARACION @CodOper, @TipoDoc, @NumeroD, @Deposito, CodInst, @CodTaxs
END