DROP TRIGGER [SESA_TG_PEDIDO]
GO
 
CREATE TRIGGER [SESA_TG_PEDIDO] ON [dbo].[SAFACT_01] 
WITH ENCRYPTION
AFTER INSERT
AS

DECLARE @TipoDoc varchar(1)
DECLARE @NumeroD Varchar(10)
DECLARE @OrdenReparacion Varchar(10)

SELECT @TipoDoc = TipoFac FROM INSERTED
SELECT @OrdenReparacion = Orden_de_reparacion FROM INSERTED

IF @TipoDoc = 'E'
BEGIN
   EXECUTE dbo.SESA_SP_PEDIDOS @TipoDoc, @OrdenReparacion
END
