-- ***********************************************************************************
-- PROCESA LOS ITEMS DE LA ORDEN DE REPARACION GUARDADA
-- 1.- Crea item de la Orden de reparacion en el historico.
-- ***********************************************************************************
DROP PROCEDURE [SESA_SP_ITEM_REPARACION]
GO 

CREATE PROCEDURE dbo.SESA_SP_ITEM_REPARACION
@TipoDoc varchar(1), @NumeroD varchar(10), @CodItem varchar(15), @NroLinea int
WITH ENCRYPTION
AS

DECLARE @Placa varchar(10)
DECLARE @DescItem varchar(80)
DECLARE @Cantidad decimal (28,2)
DECLARE @Costo decimal (28,2)
DECLARE @Precio decimal (28,2)
DECLARE @Descrip1 varchar(40)
DECLARE @Descrip2 varchar(40)
DECLARE @Descrip3 varchar(40)
DECLARE @EsServ smallint
DECLARE @CodMeca varchar(10)

BEGIN
   -- Lee los item de la orden de reparacion
   SELECT @Placa    = Y.Placa,
          @Descrip1 = X.Descrip1,
          @Descrip2 = X.Descrip2,
          @Descrip3 = X.Descrip3,
          @Cantidad = X.Cantidad,
          @Costo    = X.Costo,
          @Precio   = X.Precio,
          @EsServ   = X.EsServ,
          @CodMeca  = X.CodMeca
      FROM  dbo.SAITEMFAC AS X
      LEFT OUTER JOIN dbo.SESA_VW_ORDENES_REPARACION AS Y
      ON (X.TipoFac = Y.TipoFac AND X.NumeroD = Y.NumeroD)
      WHERE (X.TipoFac = @TipoDoc and X.NumeroD = @NumeroD AND X.CodItem = @CodItem AND X.NroLinea =@NroLinea)

   SET @DescItem = RTRIM(@Descrip1)  -- + ' ' + RTRIM(@Descrip2)  + ' ' + RTRIM(@Descrip3)

   IF NOT EXISTS (SELECT OrdenReparacion FROM dbo.SESAORIT WHERE (OrdenReparacion = @NumeroD AND CodItem = @CodItem AND NroLinea = @NroLinea))
   BEGIN
      -- Crea items de historico de ordenes de reparacion
      INSERT INTO dbo.SESAORIT (OrdenReparacion, CodItem, NroLinea, DescItem, Cantidad, Costo, Precio, EsServ, CodMeca)
         VALUES (@NumeroD, @CodItem, @NroLinea, @DescItem, @Cantidad, @Costo, @Precio, @EsServ, @CodMeca)
   END
   ELSE
   BEGIN
      -- Actualiza items de historico de ordenes de reparacion
      UPDATE dbo.SESAORIT
         SET DescItem = @DescItem,
             Cantidad = @Cantidad,
             Costo    = @Costo,
             Precio   = @Precio,
             EsServ   = @EsServ,
             CodMeca  = @CodMeca
         WHERE (OrdenReparacion = @NumeroD AND CodItem = @CodItem AND NroLinea = @NroLinea)
   END
END