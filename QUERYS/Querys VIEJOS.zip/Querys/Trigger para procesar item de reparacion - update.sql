DROP TRIGGER [SESA_TG_ITEM_REPARACION-UPDATE]
GO
 
CREATE TRIGGER [SESA_TG_ITEM_REPARACION-UPDATE] ON [dbo].[SAITEMFAC]
WITH ENCRYPTION 
AFTER UPDATE
AS

DECLARE @CodOper varchar(10)
DECLARE @TipoDoc varchar(1)
DECLARE @NumeroD varchar(10)
DECLARE @CodItem varchar(15)
DECLARE @NroLinea int

SELECT @TipoDoc  = TipoFac  FROM INSERTED
SELECT @NumeroD  = NumeroD  FROM INSERTED
SELECT @CodItem  = CodItem  FROM INSERTED
SELECT @NroLinea = NroLinea FROM INSERTED

SELECT @CodOper = Y.CodOper
FROM  dbo.SAITEMFAC AS X
LEFT OUTER JOIN dbo.SAFACT AS Y
ON (X.TipoFac = Y.TipoFac AND X.NumeroD = Y.NumeroD)
WHERE (X.TipoFac = @TipoDoc and X.NumeroD = @NumeroD)

IF @CodOper = '01-301' AND @TipoDoc = 'G'
BEGIN
   EXECUTE dbo.SESA_SP_ITEM_REPARACION @TipoDoc, @NumeroD, @CodItem, @NroLinea
END
