-- ***********************************************************************************
-- PROCESA LA ORDEN DE REPARACION CUANDO SE GUARDA
-- 1.- Revisa y corrige los datos de la Orden de reparacion.
-- 2.- Crea encabezado de la Orden de reparacion en el historico.
-- 3.- Crea ficha del vehiculo si no existe.
-- ***********************************************************************************

DROP PROCEDURE [SESA_SP_ORDEN_REPARACION]
GO 

CREATE PROCEDURE dbo.SESA_SP_ORDEN_REPARACION
@CodOper varchar(10),
@TipoDoc varchar(1),
@NumeroD varchar(10),
@Deposito varchar(10),
@CodInst varchar(10),
@CodTaxs varchar(5)
WITH ENCRYPTION
AS

DECLARE @FechaHoy datetime
DECLARE @OrdenCompra varchar(20)
DECLARE @OrdenReparacion varchar(10)
DECLARE @Placa varchar(10)
DECLARE @Codigo varchar (15)
DECLARE @Modelo varchar (40)
DECLARE @Serial varchar (35)
DECLARE @Color varchar (25)
DECLARE @FechaVenta datetime
DECLARE @Kilometraje int
DECLARE @Liquidacion varchar (15)
DECLARE @Status varchar (15)
DECLARE @Revisado varchar(3)
DECLARE @CodClie varchar (10)
DECLARE @NombClie varchar (40)
DECLARE @CodVend varchar (10)
DECLARE @FechaE datetime 
DECLARE @TipoFac varchar (1)
DECLARE @NroFact varchar (10)
DECLARE @Notas1 varchar (60)
DECLARE @Notas2 varchar (60)
DECLARE @Notas3 varchar (60)
DECLARE @Notas4 varchar (60)
DECLARE @Notas5 varchar (60)
DECLARE @Notas6 varchar (60)
DECLARE @Notas7 varchar (60)
DECLARE @Notas8 varchar (60)
DECLARE @Notas9 varchar (60)
DECLARE @Notas10 varchar (60)
DECLARE @FechaInicio datetime
DECLARE @FechaFin datetime
DECLARE @Marca varchar(20)
DECLARE @MontoIVA decimal (23,2)
DECLARE @EsPorct smallint
DECLARE @Instancia int
DECLARE @CodItem varchar(10)
DECLARE @DescItem varchar(80)
DECLARE @NroLinea int
DECLARE @Cantidad decimal (28,2)
DECLARE @Costo decimal (28,2)
DECLARE @Precio decimal (28,2)
DECLARE @Descrip1 varchar(40)
DECLARE @Descrip2 varchar(40)
DECLARE @Descrip3 varchar(40)

SET @FechaHoy = getdate()
SET @Modelo = 'NO EXISTE'
SET @Instancia = 12

BEGIN
   -- Toma los datos originales de la orden de reparacion y los prepara
   SELECT @Placa       = UPPER(X.Placa),
          @OrdenCompra = UPPER(X.Orden_de_compra),
          @Codigo      = UPPER(ISNULL(X.Codigo, '')),
          @Serial      = UPPER(X.Serial),
          @Color       = UPPER(X.Color),
          @FechaVenta  = X.Fecha_venta,
          @Kilometraje = ISNULL(X.Kilometraje,0),
          @Status      = UPPER(ISNULL(X.Status, '')),
          @Liquidacion = UPPER(ISNULL(X.Liquidacion, '')),
          @Revisado    = UPPER(X.Revisado),
          @CodOper     = Y.CodOper,
          @CodClie     = Y.CodClie,
          @NombClie    = Y.Descrip,
          @CodVend     = Y.CodVend,
          @FechaE      = Y.FechaE,
          @TipoFac     = Y.TipoFac,
          @NroFact     = Y.NumeroD,
          @Notas1      = Y.Notas1,
          @Notas2      = Y.Notas2,
          @Notas3      = Y.Notas3,
          @Notas4      = Y.Notas4,
          @Notas5      = Y.Notas5,
          @Notas6      = Y.Notas6,
          @Notas7      = Y.Notas7,
          @Notas8      = Y.Notas8,
          @Notas9      = Y.Notas9,
          @Notas10     = Y.Notas10
   FROM  dbo.SESA_VW_ORDENES_REPARACION AS X
   LEFT OUTER JOIN dbo.SAFACT AS Y
   ON (X.TipoFac = Y.TipoFac AND X.NumeroD = Y.NumeroD)
   WHERE (X.TipoFac = @TipoDoc and X.NumeroD = @NumeroD)


   IF (SUBSTRING(@Liquidacion,1,5) = 'INTER') SET @Liquidacion = 'INTERNA'
   ELSE
      IF (SUBSTRING(@Liquidacion,1,5) = 'GARAN') SET @Liquidacion = 'GARANTIA'
      ELSE
         IF (SUBSTRING(@Liquidacion,1,5) = 'CONTA') SET @Liquidacion = 'CONTADO'
         ELSE
            IF (SUBSTRING(@Liquidacion,1,5) = 'CREDI') SET @Liquidacion = 'CREDITO'
            ELSE 
               IF (SUBSTRING(@Liquidacion,1,5) = 'ANULA') SET @Liquidacion = 'ANULACION'
               ELSE 
                  SET @Liquidacion = '???'

   -- PROCESA LA OR SI STATUS = 'NUEVA'
   -- Actualiza extension del documento en espera
   -- Falta incluir en este caso: @FechaInicio = @FechaHoy,
   IF (UPPER(SUBSTRING(@Status,1,1)) = 'N' or LEN(@Status) = 0) -- NUEVA
   BEGIN
      UPDATE dbo.SESA_VW_ORDENES_REPARACION
      SET Orden_de_reparacion = @NumeroD,
          Codigo = @Codigo,
          Serial = @Serial,
          Color  = @Color,
          Orden_de_compra = @NumeroD,
          Status = 'NUEVA',
          Placa = @Placa,
          Kilometraje = @Kilometraje,
          Liquidacion = @Liquidacion,
          Revisado = ''
      WHERE (TipoFac = @TipoDoc and NumeroD = @NumeroD)
   END

   -- PROCESA LA OR SI STATUS = 'PROCESO'
   -- Actualiza extension del documento en espera
   IF (UPPER(SUBSTRING(@Status,1,1)) = 'P') -- PROCESO
   BEGIN
      UPDATE dbo.SESA_VW_ORDENES_REPARACION
      SET Orden_de_reparacion = @NumeroD,
          Codigo = @Codigo,
          Serial = @Serial,
          Color  = @Color,
          Orden_de_compra = @NumeroD,
          Status = 'PROCESO',
          Placa = @Placa,
          Kilometraje = @Kilometraje,
          Liquidacion = @Liquidacion,
          Revisado = ''
      WHERE (TipoFac = @TipoDoc and NumeroD = @NumeroD)
   END

   -- PROCESA LA OR SI STATUS = 'CERRADA'
   -- Actualiza extension del documento en espera
   IF (UPPER(SUBSTRING(@Status,1,1)) = 'C') -- CERRADA
   BEGIN
      -- Actualiza orden de reparacion
      UPDATE dbo.SESA_VW_ORDENES_REPARACION
      SET Orden_de_reparacion = @NumeroD,
          Codigo = @Codigo,
          Serial = @Serial,
          Color  = @Color,
          Orden_de_compra = @NumeroD,
          Status = 'CERRADA',
          Placa = @Placa,
          Kilometraje = @Kilometraje,
          Liquidacion = @Liquidacion,
          Revisado = @Revisado
      WHERE (TipoFac = @TipoDoc and NumeroD = @NumeroD)
   END


   -- ENCABEZADO DE HISTORICO DE ORDENES DE REPARACION
   -- Elimina la misma Orden de Reparacion con otra placa
   IF EXISTS (SELECT Placa FROM dbo.SESAOR WHERE (OrdenReparacion = @NumeroD))
   BEGIN
      DELETE FROM dbo.SESAOR
      WHERE (OrdenReparacion = @NumeroD)
      DELETE FROM dbo.SESAORIT
      WHERE (OrdenReparacion = @NumeroD)
   END

   IF NOT EXISTS (SELECT Placa, OrdenReparacion FROM dbo.SESAOR WHERE (Placa = @Placa AND OrdenReparacion = @NumeroD))
   BEGIN
      -- Crea encabezado de ordenes de reparacion
      INSERT dbo.SESAOR (Placa, OrdenReparacion, FechaInicio, FechaFinal, Kilometraje, Liquidacion, Revisado,
                         CodClie, NombClie, CodVend, TipoFac, NroFact, Notas1, Notas2, Notas3, Notas4, Notas5, Notas6, Notas7, Notas8, Notas9, Notas10)
      VALUES (@Placa, @NumeroD, @FechaE, @FechaE, @Kilometraje, @Liquidacion, @Revisado,
              @CodClie, @NombClie, @CodVend, @TipoFac, @NroFact, @Notas1, @Notas2, @Notas3, @Notas4, @Notas5, @Notas6, @Notas7, @Notas8, @Notas9, @Notas10)
   END
   ELSE
   BEGIN
      -- Actualiza encabezado de ordenes de reparacion
      UPDATE dbo.SESAOR
         SET OrdenReparacion = @NumeroD,
             Placa       = @Placa,
             FechaInicio = @FechaE,
             FechaFinal  = @FechaE,
             Kilometraje = @Kilometraje,
             Liquidacion = @Liquidacion,
             Status      = @Status,
             Revisado    = @Revisado,
             TipoFac     = @TipoFac,
             NroFact     = @NroFact,
             CodClie     = @CodClie,
             NombClie    = @NombClie,
             CodVend     = @CodVend,
             Notas1      = @Notas1,
             Notas2      = @Notas2,
             Notas3      = @Notas3,
             Notas4      = @Notas4,
             Notas5      = @Notas5,
             Notas6      = @Notas6,
             Notas7      = @Notas7,
             Notas8      = @Notas8,
             Notas9      = @Notas9,
             Notas10     = @Notas10
      WHERE (Placa = @Placa AND OrdenReparacion = @NumeroD)
   END


   -- CREA TODA LA DATA DEL VEHICULO
   IF LEN(@Codigo) > 3
      SELECT @Modelo = Descrip FROM dbo.[SAPROD] WHERE (CodProd = @Codigo)

   IF NOT EXISTS (SELECT * FROM dbo.[SAPROD] WHERE (CodProd = @Placa))
   BEGIN
      -- Crea vehiculo en inventario
      INSERT INTO dbo.[SAPROD] (CodProd, Descrip, CodInst) 
      VALUES (@Placa, @Modelo, @Instancia)

      -- Crea registro de existencia
      INSERT INTO dbo.[SAEXIS] (CodProd, CodUbic, Existen) 
      VALUES (@Placa, @Deposito, 0)

      -- Crea registro de impuesto
      SELECT @MontoIVA = MtoTax, @EsPorct = EsPorct FROM dbo.[SATAXES] WHERE (CodTaxs = @CodTaxs)
      INSERT INTO SATAXPRD (CodProd, CodTaxs, Monto, EsPorct) 
      VALUES (@Placa, @CodTaxs, @MontoIVA, @EsPorct)

      -- Crea datos adicionales del vehiculo
      SELECT @Serial = NroSerial FROM dbo.[SASEPRCOM] WHERE (TipoCom = @TipoDoc AND NumeroD = @NumeroD)
      INSERT INTO dbo.SESA_VW_VEHICULOS (CodProd, Codigo, Serial, Color, Fecha_venta, Kilometraje) 
      VALUES (@Placa, @Codigo, @Serial, @Color, @FechaVenta, @Kilometraje)
   END
   ELSE
   BEGIN
      -- Actualiza datos adicionales del vehiculo
      UPDATE dbo.SESA_VW_VEHICULOS
      SET Kilometraje = @Kilometraje
      WHERE (CodProd = @Placa)
   END


   -- ACTUALIZA LA ORDEN DE REPARACION
   SELECT @Codigo      = UPPER(ISNULL(Codigo, '')),
          @Serial      = UPPER(Serial),
          @Color       = UPPER(Color),
          @FechaVenta  = Fecha_venta
   FROM  dbo.SESA_VW_VEHICULOS
   WHERE (CodProd = @Placa)

   UPDATE dbo.SESA_VW_ORDENES_REPARACION
   SET Codigo = @Codigo,
       Serial = @Serial,
       Color  = @Color,
       Fecha_Venta = @FechaVenta
   WHERE (TipoFac = @TipoDoc and NumeroD = @NumeroD)

   -- ACTUALIZA ENCABEZADO PRINCIPAL DE LA ORDEN DE REPARACION
   UPDATE dbo.SAFACT
   SET OrdenC = @NumeroD
   WHERE (TipoFac = @TipoDoc and NumeroD = @NumeroD)

END