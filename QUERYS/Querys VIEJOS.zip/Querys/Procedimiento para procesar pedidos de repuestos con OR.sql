-- ***************************************************************************
-- AGREGA REPUESTOS PEDIDOS A LA ORDEN DE REPARACION (FACTURA EN ESPERA)
-- ***************************************************************************
DROP PROCEDURE [SESA_SP_PEDIDOS]
GO 

CREATE PROCEDURE dbo.SESA_SP_PEDIDOS
@TipoDoc varchar(1), @OrdenReparacion Varchar(10)
WITH ENCRYPTION
AS

DECLARE @NroPedido varchar(10)
DECLARE @CodItem varchar(15)
DECLARE @NroLinea int
DECLARE @CodUbic varchar(10)
DECLARE @Descrip1 varchar(50)
DECLARE @Cantidad decimal (28,2)
DECLARE @Costo decimal (28,2)
DECLARE @Precio decimal (28,2)

IF EXISTS (SELECT NumeroD FROM dbo.SAFACT WHERE (TipoFac = 'G' and NumeroD = @OrdenReparacion))
BEGIN
   DECLARE MIREG CURSOR FOR
   SELECT DISTINCT X.NumeroD, LTRIM(X.CodItem), X.CodUbic, x.Descrip1, X.Costo, X.Cantidad, X.Precio
   FROM dbo.SAITEMFAC AS X
   LEFT OUTER JOIN dbo.SESA_VW_ORDENES_REPARACION AS Y
   ON (X.TipoFac = Y.TipoFac and X.NumeroD = Y.NumeroD)
   WHERE (X.TipoFac = @TipoDoc and Y.Orden_de_reparacion = @OrdenReparacion)
   OPEN MIREG
   FETCH NEXT FROM MIREG INTO @NroPedido, @CodItem, @CodUbic, @Descrip1, @Costo, @Cantidad, @Precio
   WHILE (@@FETCH_STATUS = 0) 
   BEGIN

--   INSERT INTO dbo.TRAZA (TipoDoc, NumeroD, CodItem, Descrip1, Cantidad, Precio)
--   VALUES ('G', @OrdenReparacion, @CodItem, @Descrip1, @Cantidad, @Precio)

      IF NOT EXISTS (SELECT NumeroD FROM dbo.SAITEMFAC WHERE (TipoFac = 'G' and NumeroD = @OrdenReparacion and LTRIM(CodItem) = LTRIM(@CodItem)))
      BEGIN
         SELECT @NroLinea = NroLinea + 1
         FROM  dbo.SAITEMFAC
         WHERE (TipoFac = 'G' and NumeroD = @OrdenReparacion)

         INSERT INTO dbo.SAITEMFAC (TipoFac, NumeroD, CodItem, NroLinea, CodUbic, Descrip1, Costo, Precio)
         VALUES ('G', @OrdenReparacion, @CodItem, @NroLinea, @CodUbic, @Descrip1, @Costo, @Precio)
      END

      SELECT @Cantidad = SUM(X.Cantidad)
      FROM  dbo.SAITEMFAC AS X
      LEFT OUTER JOIN dbo.SESA_VW_ORDENES_REPARACION AS Y
      ON (X.TipoFac = Y.TipoFac and X.NumeroD = Y.NumeroD)
      WHERE (X.TipoFac = @TipoDoc and Y.Orden_de_reparacion = @OrdenReparacion and X.CodItem = @CodItem)

      UPDATE dbo.SAITEMFAC
      SET Cantidad = @Cantidad, Precio = @Precio
      WHERE (TipoFac = 'G' and NumeroD = @OrdenReparacion and CodItem = @CodItem)

      FETCH NEXT FROM MIREG INTO @NroPedido, @CodItem, @CodUbic, @Descrip1, @Costo, @Cantidad, @Precio
   END
   CLOSE MIREG
   DEALLOCATE MIREG
END